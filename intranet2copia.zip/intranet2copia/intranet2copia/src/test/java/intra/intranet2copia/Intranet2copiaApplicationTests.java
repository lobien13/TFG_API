package intra.intranet2copia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Intranet2copiaApplicationTests {

    @Test
    void contextLoads() {
    }

}
