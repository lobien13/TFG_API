package intra.intranet2copia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Intranet2copiaApplication {

    public static void main(String[] args) {
        SpringApplication.run(Intranet2copiaApplication.class, args);
    }

}
